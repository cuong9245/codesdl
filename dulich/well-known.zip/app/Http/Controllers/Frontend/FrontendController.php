<?php

namespace App\Http\Controllers\Frontend;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Models\Promotion;
use App\Models\Tour;
use Illuminate\Support\Facades\Storage;
use App\Models\places;
use App\Models\GroupTour;
use File;
use Flash;
use Mail;
use Validator;

class FrontendController extends Controller
{
    public function home()
    {
    	return view('Frontend.home');
    }

    public function contact()
    {
    	return view('Frontend.contact');
    }

    public function promotionShows()
    {
    	$promotions = Promotion::all();
    	return view('Frontend.promotion',compact('promotions'));
    }

    public function promotionDetail($id)
    {
    	$promotion  = Promotion::where('url_rewrite', $id)->first();

    	if (empty($promotion)) {
    		return abort('404');
    	}
    	$promotions = Promotion::find($promotion->id);

    	return view('Frontend.promotionDetail',compact('promotions'));
    }
    //xóa token trên url
    public function findtour(Request $request)
    {
		if (!empty($_GET['_token'])) {
			if ($request->search =="") {

			
	

				return redirect()->back()->with('messageInfomation', 'bạn chưa nhập thông tin!');;
			}
			return redirect("/search/".$request->search);
		}
    	
    }
    //search dữ liệu
    public function search($id)
    {
    	$tours = Tour::where('name','like', $id)->first();

    	$place = places::where('name', 'like',$id)->get();

    	// if (empty($tour)&&empty($place)) {

    	// 	return abort('404');
    	// }


    	if (isset($tours)) {
    		
    		$tour = Tour::where('name','like', $id)->get();
    		return view('Frontend.search',compact('tour'));
    	}

    	else{
    		foreach ($place as $places) {
    			
    			$tour[] = Tour::find($places->places_id);
    		}
    		return view('Frontend.search',compact('tour'));

    	}
    	
    }

    public function result()
    {
    	return view('Frontend.result');
    }

    public function contacts(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'txtHoTen'                  => 'required',   
            'placeholder'               => 'required',
            'mobile'                    => 'required',   
            'pers'                      => 'required',
            'address'                   => 'required',   
            'title'                     => 'required',
            'feedback'                  => 'required',
        ]);
        if ($validator->fails()) {
            return redirect()->back()->withErrors($validator)->withInput();
        }
        else{
            $name     = $request->txtHoTen;
            $email    = $request->txtEmail;
            $mobile   = $request->txtDienThoai;
            $pers     = $request->txtSoKhach;
            $address  = $request->txtDiaChi;
            $title    = $request->txtTieuDe;
            $feedback = $request->txtNoiDung;

            $GLOBALS['email'] = $request->Email;
            Mail::send('Frontend.mailCT', array('name'=>$name,'email'=>$email, 'content'=>$feedback,'subject'=>$title), 

            function($message){
              
               $message->to($GLOBALS['email'], 'Admin-FarEarstour')->subject('contact');
            });
        } 
    }

    public function groupTourShow($id)
    {
        
        $url       = GroupTour::where('url_rewrite', $id)->first();

        if(empty($url)){

            return abort('404');

        }

        $GroupTour = Tour::where('groupTour', $url->id)->get();

        return view('Frontend.groupTour', compact('GroupTour'));

    }
}
