
<?php 

require ('route-user.php');

Route::get('/','Frontend\FrontendController@home')->name('home');

Route::get('tin-tuc','Frontend\newsController@listNews')->name('tin tuc');

Route::get('reads','Frontend\TourController@readFile');

Route::get('tin-tuc/{id}','Frontend\newsController@newsDetail')->name('newsDetail');

Route::get('dia-diem/{id}','Frontend\TourController@address')->name('diadiem');

Route::get('/contact','Frontend\FrontendController@contact')->name('contact');

Route::post('/booktour','Frontend\TourController@booktour');

Route::get('/mails','Frontend\TourController@mail');

Route::get('/result','Frontend\TourController@getOnepay');

Route::get('/read','Frontend\TourController@readFile');

Route::get('/time-tour','Frontend\TourController@timeTour')->name('time-tour');

Route::get('discount-tour','Frontend\TourController@discountTour')->name('discount-tour');

Route::get('/tour-detail/{id}','Frontend\TourController@tourDetail')->name('tourDetail');

Route::get('/promotion','Frontend\FrontendController@promotionShows')->name('promotions');

Route::get('/promotion/{id}','Frontend\FrontendController@promotionDetail')->name('promotionsDetail');

Route::get('find','Frontend\FrontendController@findtour')->name('find');

Route::get('search/{id}', 'Frontend\FrontendController@search')->name('search');

Route::get('results', 'Frontend\FrontendController@result')->name('results');

Route::get('replace', 'Frontend\FrontendController@replaceWord');

Route::get('groupTour/{id}', 'Frontend\FrontendController@groupTourShow')->name('GroupTour');