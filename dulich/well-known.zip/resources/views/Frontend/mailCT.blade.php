<table border="0" cellpadding="1" cellspacing="1" style="width:100%">
	<tbody>
		<tr>
			<td>Cher/Ch&egrave;re&nbsp;<strong>{{$name}}</strong><br />
			Merci beaucoup de votre confiance.&nbsp;Ceci est un email automatique pour confirmer la r&eacute;ception de votre demande. Notre &eacute;quipe vous contactera dans le plus bref d&eacute;lai, en fran&ccedil;ais.<br />
			Si personne de notre &eacute;quipe ne vous contactera dans 48h, nous vous remercions de bien vouloir transf&eacute;rer cet email &agrave;&nbsp;<a href="mailto:sales@fareastour.com">sales@fareastour.com</a>&nbsp;<br />
			​En cas d&#39;urgence, veuillez nous contacter par la ligne t&eacute;l&eacute;phonique (24h/24) : (+84) 3 77 08 18 88 pour un soutien plus rapide!</td>
		</tr>
	</tbody>
</table>

<table border="0" cellpadding="1" cellspacing="1" style="width:100%">
	<tbody>
		<tr>
			<td colspan="2" style="background-color:#cccccc; height:25px"><strong>INFORMATIONS DU CONTACT</strong><strong>:</strong></td>
		</tr>
		<tr>
			<td style="background-color:#ffffff; height:25px"><strong>Nom et pr&eacute;nom:</strong></td>
			<td style="background-color:#ffffff; height:25px">{{$name}}</td>
		</tr>
		<tr>
			<td style="background-color:#ffffff; height:25px"><strong>Email:</strong></td>
			<td style="background-color:#ffffff; height:25px">{{$email}}</td>
		</tr>
		<tr>
			<td style="background-color:#ffffff; height:25px"><strong>T&eacute;l&eacute;phone:</strong></td>
			<td style="background-color:#ffffff; height:25px">{{$content}}</td>
		</tr>
		
		<tr>
			<td style="background-color:#ffffff; height:25px"><strong>Contenu :</strong></td>
			<td style="background-color:#ffffff; height:25px">{{$content}}</td>
		</tr>
	</tbody>
</table>

<p>Cordialement.</p>

<p>___</p>

<p><strong>Far East Tour - Agence de voyage sur mesure au Vietnam</strong><br />
Si&egrave;ge principal: 3B rue Thi Sach, dist. Hai Ba Trung, Hanoi, Vietnam.<br />
Bureau &agrave; Ho Chi Minh ville: 58 rue Dien Bien Phu, 17e quartier, arr. Binh Thanh, Hochiminh ville.<br />
Tel: +84 24 37 47 58 77&nbsp;<br />
Hotline : +84 3 77 08 18 88<br />
Email: sales@fareastour.com</p>
