<div class="table-responsive">
    <table class="table" id="groupTours-table">
        <thead>
            <tr>
                <th>Name</th>
        <th>Url Rewrite</th>
        <th>Image</th>
                <th colspan="3">Action</th>
            </tr>
        </thead>
        <tbody>
        <?php $__currentLoopData = $groupTours; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $groupTour): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($groupTour->Name); ?></td>
            <td><?php echo e($groupTour->url_rewrite); ?></td>
            <td><img src="<?php echo $groupTour->image; ?>" alt="<?php echo $groupTour->image; ?>" class="img-responsive" width="150" height="150"></td>
                <td>
                    <?php echo Form::open(['route' => ['groupTours.destroy', $groupTour->id], 'method' => 'delete']); ?>

                    <div class='btn-group'>
                        <a href="<?php echo e(route('groupTours.show', [$groupTour->id])); ?>" class='btn btn-default btn-xs'><i class="glyphicon glyphicon-eye-open"></i></a>
                        <a href="<?php echo e(route('groupTours.edit', [$groupTour->id])); ?>" class='btn btn-default btn-xs'><i class="glyphicon glyphicon-edit"></i></a>
                        <?php echo Form::button('<i class="glyphicon glyphicon-trash"></i>', ['type' => 'submit', 'class' => 'btn btn-danger btn-xs', 'onclick' => "return confirm('Are you sure?')"]); ?>

                    </div>
                    <?php echo Form::close(); ?>

                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>
