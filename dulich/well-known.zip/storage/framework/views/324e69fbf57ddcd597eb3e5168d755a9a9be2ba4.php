<!-- Name Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('name', 'Name:'); ?>

    <?php echo Form::text('name', null, ['class' => 'form-control']); ?>

</div>

<!-- Image Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('image', 'Image:'); ?>

    <?php echo Form::file('image'); ?>

</div>
<div class="clearfix"></div>

<!-- Customer Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('customer', 'Customer:'); ?>

    <?php echo Form::text('customer', null, ['class' => 'form-control']); ?>

</div>

<!-- Submit Field -->
<div class="form-group col-sm-12">
    <?php echo Form::submit('Save', ['class' => 'btn btn-primary']); ?>

    <a href="<?php echo e(route('cities.index')); ?>" class="btn btn-default">Cancel</a>
</div>
