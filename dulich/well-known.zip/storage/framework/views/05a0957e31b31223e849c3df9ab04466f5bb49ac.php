<!-- Title Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('Title', 'Title:'); ?>

    <?php echo Form::text('Title', null, ['class' => 'form-control','maxlength' => 255]); ?>

</div>

<!-- Image Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('image', 'Image:'); ?>

    <?php echo Form::file('image'); ?>

</div>
<div class="clearfix"></div>

<!-- Detail Field -->
<div class="form-group col-sm-12 col-lg-12">
    <?php echo Form::label('Detail', 'Detail:'); ?>

    <?php echo Form::textarea('Detail', null, ['class' => 'form-control']); ?>

</div>

<!-- Submit Field -->
<div class="form-group col-sm-12">
    <?php echo Form::submit('Save', ['class' => 'btn btn-primary']); ?>

    <a href="<?php echo e(route('promotions.index')); ?>" class="btn btn-default">Cancel</a>
</div>
