<!-- Name Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('Name', 'Name:'); ?>

    <?php echo Form::text('Name', null, ['class' => 'form-control']); ?>

</div>

<!-- Code Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('Code', 'Code:'); ?>

    <?php echo Form::text('Code', null, ['class' => 'form-control']); ?>

</div>

<!-- Departureday Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('departureDay', 'Departureday:'); ?>

    <?php echo Form::text('departureDay', null, ['class' => 'form-control', 'autocomplete'=>'off']); ?>

</div>

<!-- Departuretime Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('departureTime', 'Departuretime:'); ?>

    <?php echo Form::text('departureTime', null, ['class' => 'form-control', 'id'=>'timepicker_alt_input', 'autocomplete'=>'off']); ?>

</div>

<!-- Time Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('Time', 'Time:'); ?>

    <?php echo Form::text('Time', null, ['class' => 'form-control']); ?>

</div>

<!-- Startplace Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('startPlace', 'Startplace:'); ?>

    <?php echo Form::text('startPlace', null, ['class' => 'form-control']); ?>

</div>

<!-- Price Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('price', 'Price:'); ?>

    <?php echo Form::text('price', null, ['class' => 'form-control']); ?>

</div>

<!-- Max Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('max', 'Max:'); ?>

    <?php echo Form::number('max', null, ['class' => 'form-control']); ?>

</div>

<!-- Discountprice Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('discountPrice', 'Discountprice:'); ?>

    <?php echo Form::text('discountPrice', null, ['class' => 'form-control']); ?>

</div>

<!-- Summary Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('Summary', 'Summary:'); ?>

    <?php echo Form::text('Summary', null, ['class' => 'form-control']); ?>

</div>

<!-- Note Field -->
<div class="form-group col-sm-12 col-lg-12">
    <?php echo Form::label('note', 'Note:'); ?>

    <?php echo Form::textarea('note', null, ['class' => 'form-control', 'id'=>'editor']); ?>

</div>

<!-- Booked Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('booked', 'Booked:'); ?>

    <?php echo Form::text('booked', null, ['class' => 'form-control', 'disabled']); ?>

</div>

<!-- City Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('city', 'City:'); ?>

    <?php echo Form::select('city', $city, null, ['class' => 'form-control']); ?>

</div>


<!-- Group Tour Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('groupTour', 'GroupTour:'); ?>

    <?php echo Form::select('groupTour', $GroupTour, null, ['class' => 'form-control']); ?>

</div>

<!-- Submit Field -->
<div class="form-group col-sm-12">
    <?php echo Form::submit('Save', ['class' => 'btn btn-primary']); ?>

    <a href="<?php echo e(route('tours.index')); ?>" class="btn btn-default">Cancel</a>
</div>


