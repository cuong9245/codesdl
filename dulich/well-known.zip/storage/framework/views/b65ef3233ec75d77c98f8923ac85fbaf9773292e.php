<!-- Id Field -->
<div class="form-group">
    <?php echo Form::label('id', 'Id:'); ?>

    <p><?php echo e($tour->id); ?></p>
</div>

<!-- Name Field -->
<div class="form-group">
    <?php echo Form::label('Name', 'Name:'); ?>

    <p><?php echo e($tour->Name); ?></p>
</div>

<!-- Code Field -->
<div class="form-group">
    <?php echo Form::label('Code', 'Code:'); ?>

    <p><?php echo e($tour->Code); ?></p>
</div>

<!-- Departureday Field -->
<div class="form-group">
    <?php echo Form::label('departureDay', 'Departureday:'); ?>

    <p><?php echo e($tour->departureDay); ?></p>
</div>

<!-- Departuretime Field -->
<div class="form-group">
    <?php echo Form::label('departureTime', 'Departuretime:'); ?>

    <p><?php echo e($tour->departureTime); ?></p>
</div>

<!-- Time Field -->
<div class="form-group">
    <?php echo Form::label('Time', 'Time:'); ?>

    <p><?php echo e($tour->Time); ?></p>
</div>

<!-- Startplace Field -->
<div class="form-group">
    <?php echo Form::label('startPlace', 'Startplace:'); ?>

    <p><?php echo e($tour->startPlace); ?></p>
</div>

<!-- Price Field -->
<div class="form-group">
    <?php echo Form::label('price', 'Price:'); ?>

    <p><?php echo e($tour->price); ?></p>
</div>

<!-- Max Field -->
<div class="form-group">
    <?php echo Form::label('max', 'Max:'); ?>

    <p><?php echo e($tour->max); ?></p>
</div>

<!-- Discountprice Field -->
<div class="form-group">
    <?php echo Form::label('discountPrice', 'Discountprice:'); ?>

    <p><?php echo e($tour->discountPrice); ?></p>
</div>

<!-- Summary Field -->
<div class="form-group">
    <?php echo Form::label('Summary', 'Summary:'); ?>

    <p><?php echo e($tour->Summary); ?></p>
</div>

<!-- Note Field -->
<div class="form-group">
    <?php echo Form::label('note', 'Note:'); ?>

    <p><?php echo e($tour->note); ?></p>
</div>

<!-- Booked Field -->
<div class="form-group">
    <?php echo Form::label('booked', 'Booked:'); ?>

    <p><?php echo e($tour->booked); ?></p>
</div>

<!-- City Field -->
<div class="form-group">
    <?php echo Form::label('city', 'City:'); ?>

    <p><?php echo $tour->citytour->name; ?></p>
</div>

<!-- Created At Field -->
<div class="form-group">
    <?php echo Form::label('created_at', 'Created At:'); ?>

    <p><?php echo e($tour->created_at); ?></p>
</div>

<!-- Updated At Field -->
<div class="form-group">
    <?php echo Form::label('updated_at', 'Updated At:'); ?>

    <p><?php echo e($tour->updated_at); ?></p>
</div>

