<li class="<?php echo e(Request::is('banners*') ? 'active' : ''); ?>">
    <a href="<?php echo e(route('banners.index')); ?>"><i class="fa fa-edit"></i><span>Banners</span></a>
</li>

<li class="<?php echo e(Request::is('tours*') ? 'active' : ''); ?>">
    <a href="<?php echo e(route('tours.index')); ?>"><i class="fa fa-edit"></i><span>Tours</span></a>
</li>

<!-- <li class="<?php echo e(Request::is('imageTours*') ? 'active' : ''); ?>">
    <a href="<?php echo e(route('imageTours.index')); ?>"><i class="fa fa-edit"></i><span>Image Tours</span></a>
</li> -->

<!-- <li class="<?php echo e(Request::is('places*') ? 'active' : ''); ?>">
    <a href="<?php echo e(route('places.index')); ?>"><i class="fa fa-edit"></i><span>Places</span></a>
</li> -->

<li class="<?php echo e(Request::is('cities*') ? 'active' : ''); ?>">
    <a href="<?php echo e(route('cities.index')); ?>"><i class="fa fa-edit"></i><span>Cities</span></a>
</li>

<li class="<?php echo e(Request::is('whySelects*') ? 'active' : ''); ?>">
    <a href="<?php echo e(route('whySelects.index')); ?>"><i class="fa fa-edit"></i><span>Why Selects</span></a>
</li>

<!-- <li class="<?php echo e(Request::is('programTours*') ? 'active' : ''); ?>">
    <a href="<?php echo e(route('programTours.index')); ?>"><i class="fa fa-edit"></i><span>Program Tours</span></a>
</li> -->

<li class="<?php echo e(Request::is('news*') ? 'active' : ''); ?>">
    <a href="<?php echo e(route('news.index')); ?>"><i class="fa fa-edit"></i><span>News</span></a>
</li>


<li class="<?php echo e(Request::is('menus*') ? 'active' : ''); ?>">
    <a href="<?php echo e(route('menus.index')); ?>"><i class="fa fa-edit"></i><span>Menus</span></a>
</li>

<li class="<?php echo e(Request::is('groupTours*') ? 'active' : ''); ?>">
    <a href="<?php echo e(route('groupTours.index')); ?>"><i class="fa fa-edit"></i><span>Group Tours</span></a>
</li>

<li class="<?php echo e(Request::is('promotions*') ? 'active' : ''); ?>">
    <a href="<?php echo e(route('promotions.index')); ?>"><i class="fa fa-edit"></i><span>Promotions</span></a>
</li>

<li class="<?php echo e(Request::is('rewriteWords*') ? 'active' : ''); ?>">
    <a href="<?php echo e(route('rewriteWords.index')); ?>"><i class="fa fa-edit"></i><span>Rewrite Words</span></a>
</li>

