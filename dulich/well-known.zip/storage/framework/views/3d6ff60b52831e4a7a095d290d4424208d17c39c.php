<!-- Image Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('image', 'Image:'); ?>

    <?php echo Form::file('image'); ?>

</div>
<div class="clearfix"></div>

<!-- Title Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('title', 'Title:'); ?>

    <?php echo Form::text('title', null, ['class' => 'form-control','maxlength' => 255]); ?>

</div>

<!-- Summary Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('summary', 'Summary:'); ?>

    <?php echo Form::text('summary', null, ['class' => 'form-control','maxlength' => 255]); ?>

</div>

<!-- Tourrelated Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('TourRelated', 'Tourrelated:'); ?>

    <?php echo Form::text('TourRelated', null, ['class' => 'form-control']); ?>

</div>

<!-- Detail Field -->
<div class="form-group col-sm-12 col-lg-12">
    <?php echo Form::label('Detail', 'Detail:'); ?>

    <?php echo Form::textarea('Detail', null, ['class' => 'form-control']); ?>

</div>

<!-- Submit Field -->
<div class="form-group col-sm-12">
    <?php echo Form::submit('Save', ['class' => 'btn btn-primary']); ?>

    <a href="<?php echo e(route('news.index')); ?>" class="btn btn-default">Cancel</a>
</div>
