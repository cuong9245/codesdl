<!-- Name Field -->
<?php  
    $originalMenu = array("Trang chủ","Tin Tức", "time tour", "contact", "discount tour","khuyến mãi");
    $active       = array("hide", "show");
?>
<div class="form-group col-sm-6">
    <?php echo Form::label('Name', 'Name:'); ?>

    <?php echo Form::text('Name', null, ['class' => 'form-control','maxlength' => 255]); ?>

</div>

<!-- Originalmenu Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('originalMenu', 'Originalmenu:'); ?>

    <?php echo Form::select('originalMenu', $originalMenu, null, ['class' => 'form-control']); ?>

</div>

<!-- Link Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('Link', 'Link:'); ?>

    <?php echo Form::text('Link', null, ['class' => 'form-control','maxlength' => 255]); ?>

</div>

<!-- Active Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('active', 'Active:'); ?>

    <?php echo Form::select('active', $active, null, ['class' => 'form-control']); ?>

</div>

<!-- Submit Field -->
<div class="form-group col-sm-12">
    <?php echo Form::submit('Save', ['class' => 'btn btn-primary']); ?>

    <a href="<?php echo e(route('menus.index')); ?>" class="btn btn-default">Cancel</a>
</div>
