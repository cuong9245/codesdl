<!-- Id Field -->
<div class="form-group">
    <?php echo Form::label('id', 'Id:'); ?>

    <p><?php echo e($city->id); ?></p>
</div>

<!-- Name Field -->
<div class="form-group">
    <?php echo Form::label('name', 'Name:'); ?>

    <p><?php echo e($city->name); ?></p>
</div>

<!-- Image Field -->
<div class="form-group">
    <?php echo Form::label('image', 'Image:'); ?>

    <img src="<?php echo $city->image; ?>" alt="<?php echo $city->image; ?>" class="img-responsive" width="150" height="150">
</div>

<!-- Customer Field -->
<div class="form-group">
    <?php echo Form::label('customer', 'Customer:'); ?>

    <p><?php echo e($city->customer); ?></p>
</div>

<!-- Created At Field -->
<div class="form-group">
    <?php echo Form::label('created_at', 'Created At:'); ?>

    <p><?php echo e($city->created_at); ?></p>
</div>

<!-- Updated At Field -->
<div class="form-group">
    <?php echo Form::label('updated_at', 'Updated At:'); ?>

    <p><?php echo e($city->updated_at); ?></p>
</div>

