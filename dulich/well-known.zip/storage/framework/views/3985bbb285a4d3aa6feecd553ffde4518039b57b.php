<!-- Image Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('image', 'Image:'); ?>

    <?php echo Form::file('image'); ?>

</div>
<div class="clearfix"></div>

<?php if(!empty($id)): ?>

<input type="" name="imageTour_id" class="hide" value="<?php echo e($id); ?>">

<?php endif; ?>

<!-- Submit Field -->
<div class="form-group col-sm-12">
    <?php echo Form::submit('Save', ['class' => 'btn btn-primary']); ?>

    <a href="<?php echo e(route('imageTours.index')); ?>" class="btn btn-default">Cancel</a>
</div>
