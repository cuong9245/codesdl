<div style="font-family:Arial; font:Arial">
<div style="border-color:#e87819; border-style:solid; border-width:3px 3px 3px 15px; font-family:Arial; font-size:12px; line-height:18px; padding:15px">Cher <?php echo e($name); ?>,<br />
<br />
Merci pour votre int&eacute;r&ecirc;t pour la croisi&egrave;re Cat Ba Halong avec FarEasTour &amp;&nbsp;<a href="http://www.croisierescatba.com/">www.croisierescatba.com</a><br />
<br />
Votre r&eacute;servation n&#39;a pas encore &eacute;t&eacute; confirm&eacute;e. Nos conseillers voyages traiteront votre demande et vous r&eacute;pondront dans 24 heures.<br />
<br />
&nbsp;
<table border="0" cellpadding="0" cellspacing="0" style="font-family:Arial; font-size:12px; font:Arial; line-height:20px; width:80%">
	<tbody>
		<tr>
			<td style="vertical-align:top; width:48%"><strong>information DU VOYAGE</strong><br />
			Croisi&egrave;re: <strong><?php echo e($name); ?></strong><br />
			
		</tr>
	</tbody>
</table>
<br />
<br />
<strong>information DU VOYAGE</strong><br />
Nom: <strong><?php echo e($name); ?></strong><br />
Email: <strong><?php echo e($email); ?></strong><br />
phone: <strong><?php echo e($phone); ?> </strong><br />
Num&eacute;ro de t&eacute;l&eacute;phone: <strong><?php echo e($mobilephone); ?></strong><br />
<br />
Si vous recevez cet email automatique mais personne ne vous contacte dans les 24 heures, il semble que notre agence a eu un probl&egrave;me avec des messages sortant, dans ce cas, SVP renvoyer gentiment l&#39;email automatique &agrave;&nbsp;<a href="http://sales@fareastour.com">sales@fareastour.com</a>, nos conseillers voyages vous r&eacute;pondront imm&eacute;diatement.<br />
<br />
Cordialement,
<hr />
<table border="0" cellpadding="0" cellspacing="0" style="font-family:Arial; font-size:12px; font:Arial; line-height:20px">
	<tbody>
		<tr>
			<td><img alt="" src=" <?php echo e(asset('/Frontend/images/fareastour-logo.png')); ?> " /></td>
			<td><strong>International Tour Operator Licience No. 01140/2009/TCDL &ndash; GPLHQT </strong><br />
			<span style="color:#000080; font-family:Arial,Helvetica,sans-serif; font-size:13px">Adresse: No.3B Thi Sach Str., Hai Ba Trung Dist., Hanoi , Vietnam </span><br />
			<span style="color:#000080; font-family:Arial,Helvetica,sans-serif; font-size:13px">Tel: +84 24 37475877 / Fax: +84 4 37475878</span><br />
			<span style="color:#000080; font-family:Arial,Helvetica,sans-serif; font-size:13px">Web :</span>&nbsp;<a href="http://www.croisierescatba.com" target="_blank">http://www.croisierescatba.com</a><br />
			<span style="color:#000080; font-family:Arial,Helvetica,sans-serif; font-size:13px">Email: </span><a href="mailto:sales@halongbuzz.com"> sales@fareastour.com</a> ;<span style="color:#000080; font-family:Arial,Helvetica,sans-serif; font-size:13px"> </span></td>
		</tr>
	</tbody>
</table>
</div>
</div>