<!-- Name Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('name', 'Name:'); ?>

    <?php echo Form::text('name', null, ['class' => 'form-control']); ?>

</div>

<!-- Image Field -->
<?php if(!empty($places)): ?>
	<div class="col-sm-6 disbanner">
		<div class="col-sm-3"><img src="<?php echo $places->image; ?>" alt="<?php echo $places->image; ?>" class="img-responsive" width="150" height="150"></div>
		<div class="edit-image col-sm-3" id="image-edit">
			<input type="button" value="sửa ảnh">
		</div>
	</div>
	
	<div id="add" class="col-sm-6"></div>
	<div class="form-group col-sm-6 addClass" id="remove">
	    <?php echo Form::label('image', 'Image:'); ?>

	    <?php echo Form::file('image'); ?>

	</div>

<?php else: ?>
<div class="form-group col-sm-6">
    <?php echo Form::label('image', 'Image:'); ?>

    <?php echo Form::file('image'); ?>

</div>
<?php endif; ?>

<?php if(!empty($id)): ?>

<input type="" name="places_id" class="hide" value="<?php echo e($id); ?>">

	

<?php endif; ?>


<div class="clearfix"></div>

<!-- Submit Field -->
<div class="form-group col-sm-12">
    <?php echo Form::submit('Save', ['class' => 'btn btn-primary']); ?>

    <a href="<?php echo e(route('places.index')); ?>" class="btn btn-default">Cancel</a>
</div>
