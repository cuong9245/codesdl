<!-- Name Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('Name', 'Name:'); ?>

    <?php echo Form::text('Name', null, ['class' => 'form-control','maxlength' => 255]); ?>

</div>

<!-- Image Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('image', 'Image:'); ?>

    <?php echo Form::file('image'); ?>

</div>
<div class="clearfix"></div>

<!-- Submit Field -->
<div class="form-group col-sm-12">
    <?php echo Form::submit('Save', ['class' => 'btn btn-primary']); ?>

    <a href="<?php echo e(route('groupTours.index')); ?>" class="btn btn-default">Cancel</a>
</div>
