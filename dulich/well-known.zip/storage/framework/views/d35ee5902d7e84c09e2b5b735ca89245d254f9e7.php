<!-- Name Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('name', 'Name:'); ?>

    <?php echo Form::text('name', null, ['class' => 'form-control']); ?>

</div>

<!-- Detail Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('detail', 'Detail:'); ?>

    <?php echo Form::text('detail', null, ['class' => 'form-control']); ?>

</div>

<!-- Submit Field -->
<div class="form-group col-sm-12">
    <?php echo Form::submit('Save', ['class' => 'btn btn-primary']); ?>

    <a href="<?php echo e(route('whySelects.index')); ?>" class="btn btn-default">Cancel</a>
</div>
