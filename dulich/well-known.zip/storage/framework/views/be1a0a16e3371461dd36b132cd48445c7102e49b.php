<!-- Word Field -->
<?php  
	
	$page = array('home.blade.php'=>'Trang chủ', 'news.blade.php'=>'Tin tức', 'contact.blade.php'=>'Liên hệ', 'timetour.blade.php'=>'Tour giờ chót', 'discount.blade.php'=>'Ưu đãi thanh toán trực tuyến','promotion.blade.php'=>'Khuyến mãi chi tiết','detail.blade.php'=>'Tour chi tiết','city.blade.php'=>'Điểm đến yêu thích')

?>
<div class="form-group col-sm-6">
    <?php echo Form::label('word', 'Word:'); ?>

    <?php echo Form::text('word', null, ['class' => 'form-control','maxlength' => 255]); ?>

</div>

<!-- Rewrite Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('rewrite', 'Rewrite:'); ?>

    <?php echo Form::text('rewrite', null, ['class' => 'form-control','maxlength' => 255]); ?>

</div>

<!-- Page Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('page', 'Page:'); ?>

   	<?php echo Form::select('page', $page, null, ['class' => 'form-control']); ?>

</div>

<!-- Submit Field -->
<div class="form-group col-sm-12">
    <?php echo Form::submit('Save', ['class' => 'btn btn-primary']); ?>

    <a href="<?php echo e(route('rewriteWords.index')); ?>" class="btn btn-default">Cancel</a>
</div>
