<div class="table-responsive">
    <table class="table" id="imageTours-table">
        <thead>
            <tr>
                <th>Image</th>
                <th colspan="3">Action</th>
            </tr>
        </thead>
        <tbody>
        <?php $__currentLoopData = $imageTours; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $imageTour): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><img src="<?php echo $imageTour->image; ?>" alt="<?php echo $imageTour->image; ?>" class="img-responsive" width="150" height="150"></td>
                <td>
                    <?php echo Form::open(['route' => ['imageTours.destroy', $imageTour->id], 'method' => 'delete']); ?>

                    <div class='btn-group'>
                        <a href="<?php echo e(route('imageTours.show', [$imageTour->id])); ?>" class='btn btn-default btn-xs'><i class="glyphicon glyphicon-eye-open"></i></a>
                        <a href="<?php echo e(route('imageTours.edit', [$imageTour->id])); ?>" class='btn btn-default btn-xs'><i class="glyphicon glyphicon-edit"></i></a>
                        <?php echo Form::button('<i class="glyphicon glyphicon-trash"></i>', ['type' => 'submit', 'class' => 'btn btn-danger btn-xs', 'onclick' => "return confirm('Are you sure?')"]); ?>

                    </div>
                    <?php echo Form::close(); ?>

                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>
