<div class="table-responsive">
    <table class="table" id="news-table">
        <thead>
            <tr>
                <th>Image</th>
        <th>Title</th>
        <th>Summary</th>
        <th>Tourrelated</th>
        <th>Detail</th>
                <th colspan="3">Action</th>
            </tr>
        </thead>
        <tbody>
        <?php $__currentLoopData = $news; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $news): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
               <td><img src="<?php echo $news->image; ?>" alt="<?php echo $news->image; ?>" class="img-responsive" width="150" height="150"></td>
                
            <td><?php echo e($news->title); ?></td>
            <td><?php echo e($news->summary); ?></td>
            <td><?php echo e($news->TourRelated); ?></td>
            <td><?php echo e($news->Detail); ?></td>
                <td>
                    <?php echo Form::open(['route' => ['news.destroy', $news->id], 'method' => 'delete']); ?>

                    <div class='btn-group'>
                        <a href="<?php echo e(route('news.show', [$news->id])); ?>" class='btn btn-default btn-xs'><i class="glyphicon glyphicon-eye-open"></i></a>
                        <a href="<?php echo e(route('news.edit', [$news->id])); ?>" class='btn btn-default btn-xs'><i class="glyphicon glyphicon-edit"></i></a>
                        <?php echo Form::button('<i class="glyphicon glyphicon-trash"></i>', ['type' => 'submit', 'class' => 'btn btn-danger btn-xs', 'onclick' => "return confirm('Are you sure?')"]); ?>

                    </div>
                    <?php echo Form::close(); ?>

                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>
