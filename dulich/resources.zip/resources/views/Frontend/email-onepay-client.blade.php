Email pour &nbsp;confirmation de v&ocirc;tre paiement<br />

M&eacute;thode de paiement: {{ $paymentMethod }}<br />
R&eacute;servation ID: <strong><span style="color: #FF3300;">{{ $orderID }}</span></strong><br />
Total: <strong><span style="color: #FF3300;">  {{ $amount }}  </span></strong><br />
Message: <strong><span style="color: #FF3300;">{{ $messages }}  </span></strong><br />
R&eacute;ponse: <strong><span style="color: #FF3300;"> {{ $txnResponseCode }} </span></strong><br />
Num&eacute;ro de transaction: <strong><span style="color: #FF3300;"> {{ $transactionNo }} </span></strong><br />
<br />